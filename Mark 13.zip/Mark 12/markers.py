"""markers.py - ArUco marker detection and generation (needs OpenCV >= 4.7 with aruco)."""
import cv2
import numpy as np
import config


class MarkerError(Exception):
    pass


def _dictionary(name=config.ARUCO_DICT):
    if not hasattr(cv2, "aruco"):
        raise MarkerError("cv2.aruco missing. Run: python -m pip install --upgrade opencv-python")
    return cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, name))


class MarkerDetector:
    def __init__(self, dict_name=config.ARUCO_DICT):
        self.dictionary = _dictionary(dict_name)
        if hasattr(cv2.aruco, "ArucoDetector"):
            self.detector = cv2.aruco.ArucoDetector(self.dictionary, cv2.aruco.DetectorParameters())
        else:
            self.detector = None
            self.params = cv2.aruco.DetectorParameters_create()

    def detect(self, frame):
        """Return markers biggest-first: id, size (px), center_x, center_y, corners."""
        if frame is None or frame.size == 0:
            return []
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        try:
            if self.detector is not None:
                corners, ids, _ = self.detector.detectMarkers(gray)
            else:
                corners, ids, _ = cv2.aruco.detectMarkers(gray, self.dictionary, parameters=self.params)
        except Exception as e:
            print("[Markers] detection failed:", e)
            return []
        out = []
        if ids is None:
            return out
        for c, i in zip(corners, ids.flatten()):
            pts = c.reshape(4, 2)
            size = float(np.mean([np.linalg.norm(pts[k] - pts[(k + 1) % 4]) for k in range(4)]))
            out.append({"id": int(i), "size": round(size, 1), "center_x": int(pts[:, 0].mean()),
                        "center_y": int(pts[:, 1].mean()), "corners": pts.tolist()})
        return sorted(out, key=lambda m: -m["size"])


def draw_markers(frame, markers, names=None):
    for m in markers:
        pts = np.array(m["corners"], dtype=np.int32)
        cv2.polylines(frame, [pts], True, (255, 0, 255), 2)
        label = f'Marker {m["id"]}' + (f' {names[m["id"]]}' if names and m["id"] in names else "")
        cv2.putText(frame, label, (pts[0][0], max(15, pts[0][1] - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 255), 1, cv2.LINE_AA)
    return frame


def generate_marker_image(marker_id, size=400, dict_name=config.ARUCO_DICT):
    d = _dictionary(dict_name)
    if hasattr(cv2.aruco, "generateImageMarker"):
        return cv2.aruco.generateImageMarker(d, marker_id, size)
    return cv2.aruco.drawMarker(d, marker_id, size)
