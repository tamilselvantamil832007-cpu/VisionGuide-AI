"""camera.py - Webcam handling for VisionGuide AI."""
import cv2
import config


class CameraError(Exception):
    """Raised when the camera cannot be opened or keeps failing."""


class Camera:
    def __init__(self, index=config.CAMERA_INDEX, width=config.FRAME_WIDTH,
                 height=config.FRAME_HEIGHT, max_failures=30):
        self.index, self.width, self.height = index, width, height
        self.max_failures = max_failures
        self.failures = 0
        self.cap = None

    def open(self):
        self.cap = cv2.VideoCapture(self.index, cv2.CAP_DSHOW)  # DSHOW: faster on Windows
        if not self.cap.isOpened():
            self.cap.release()
            self.cap = cv2.VideoCapture(self.index)
        if not self.cap.isOpened():
            self.cap = None
            raise CameraError(f"Could not open camera index {self.index}. "
                              "Try another index (0, 1, 2) or close apps using the camera.")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        self.failures = 0
        return self

    def read(self):
        """Return a frame, or None for one bad read. Raises only after many failures in a row."""
        if self.cap is None:
            raise CameraError("Camera is not open. Call open() first.")
        ok, frame = self.cap.read()
        if not ok or frame is None or frame.size == 0:
            self.failures += 1
            if self.failures >= self.max_failures:
                raise CameraError("Camera stopped giving frames.")
            return None
        self.failures = 0
        return frame

    def release(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *args):
        self.release()


def scan_cameras(max_index=4):
    found = []
    for i in range(max_index + 1):
        cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
        if cap.isOpened() and cap.read()[0]:
            found.append(i)
        cap.release()
    return found
