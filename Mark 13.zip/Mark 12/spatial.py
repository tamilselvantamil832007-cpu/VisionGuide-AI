"""spatial.py - Split the frame into LEFT / CENTER / RIGHT and judge each zone."""
import numpy as np
import config

CLEAR, BLOCKED, HIGH_RISK = "CLEAR", "BLOCKED", "HIGH RISK"
ZONES = ("left", "center", "right")


def _closeness(d, frame_w, frame_h):
    """Closeness 0..1 = the larger of (relative depth) and (box-size estimate).
    Big boxes are usually near, so a large object is never missed if depth is weak."""
    area = (d["x2"] - d["x1"]) * (d["y2"] - d["y1"])
    size_c = min(1.0, 3.5 * area / float(frame_w * frame_h))
    if d.get("relative_depth") is None:
        return size_c
    return max(d["relative_depth"], size_c)


def _zones_of(d, frame_w, min_overlap):
    edges = {"left": (0, frame_w / 3), "center": (frame_w / 3, 2 * frame_w / 3),
             "right": (2 * frame_w / 3, frame_w)}
    bw = max(1, d["x2"] - d["x1"])
    hit = []
    for name, (a, b) in edges.items():
        overlap = max(0, min(d["x2"], b) - max(d["x1"], a))
        if overlap / bw >= min_overlap:
            hit.append(name)
    return hit or ["center" if edges["center"][0] <= d["center_x"] < edges["center"][1]
                   else ("left" if d["center_x"] < edges["center"][0] else "right")]


def analyze_spatial_scene(detections, frame_width, frame_height,
                          blocked_threshold=config.BLOCKED_THRESHOLD,
                          high_risk_threshold=config.HIGH_RISK_THRESHOLD,
                          min_overlap=config.MIN_ZONE_OVERLAP, depth_map=None):
    worst = {z: 0.0 for z in ZONES}
    obstacles = []
    for d in detections:
        c = _closeness(d, frame_width, frame_height)
        zones = _zones_of(d, frame_width, min_overlap)
        for z in zones:
            worst[z] = max(worst[z], c)
        if c >= blocked_threshold:
            obstacles.append({"class": d["class"], "zones": zones, "closeness": round(c, 2)})

    # Wall / big obstacle: many near pixels in the middle band of a zone (needs MiDaS)
    if depth_map is not None and config.USE_DEPTH_WALLS:
        dh, dw = depth_map.shape[:2]
        band = depth_map[int(dh * 0.25):int(dh * 0.75)]       # ignore ceiling and floor
        for i, z in enumerate(ZONES):
            part = band[:, int(dw * i / 3):int(dw * (i + 1) / 3)]
            if part.size and np.mean(part >= config.WALL_DEPTH_THRESHOLD) >= config.WALL_AREA_FRACTION:
                c = float(np.median(part))
                worst[z] = max(worst[z], c)
                if c >= blocked_threshold:
                    obstacles.append({"class": "obstacle", "zones": [z], "closeness": round(c, 2)})

    def status(v):
        return HIGH_RISK if v >= high_risk_threshold else BLOCKED if v >= blocked_threshold else CLEAR

    result = {z: status(worst[z]) for z in ZONES}
    if result["center"] == HIGH_RISK:
        risk = "HIGH"
    elif BLOCKED in result.values() or HIGH_RISK in result.values():
        risk = "MEDIUM"
    else:
        risk = "LOW"
    result.update({"obstacles": obstacles, "risk_level": risk,
                   "closeness": {z: round(worst[z], 2) for z in ZONES}})
    return result
