"""FastAPI backend.  Run from project root:  python -m uvicorn backend.main:app --port 8000
Then open  http://localhost:8000  (the dashboard is served by this backend).

Two camera sources (choose in the dashboard):
  * Browser camera  - the browser asks permission, sends frames to POST /analyze  (default)
  * PC camera       - the server opens the webcam itself with OpenCV (POST /server-camera)
Env: VISIONGUIDE_AUTOSTART=1 (open PC camera at startup, default 0), VISIONGUIDE_SPEECH=0, VISIONGUIDE_CAMERA=1"""
import os
import threading
import time
from contextlib import asynccontextmanager
from typing import Optional
from fastapi import FastAPI, Request
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from starlette.concurrency import run_in_threadpool

import config
from route import RouteGraph, RouteNavigator

try:                                   # Level 3 navigator (shared with the vision engine)
    NAV = RouteNavigator(RouteGraph.load(config.MAP_FILE))
except Exception as _e:
    print("[Backend] map.json problem, navigation disabled:", _e)
    NAV = None

INDEX_FILE = os.path.join(config.BASE_DIR, "index.html")

S = {"status": "stopped", "error": None, "engine": None, "source": "none",
     "stop": threading.Event(),            # whole server shutting down
     "worker": None, "worker_stop": threading.Event()}
ENGINE_LOCK = threading.Lock()             # engine creation
ANALYZE_LOCK = threading.Lock()            # one browser frame at a time


def _get_engine():
    """Create the vision engine once (loads YOLO / MiDaS). Raises if loading fails."""
    with ENGINE_LOCK:
        if S["engine"] is None:
            from engine import VisionEngine
            S["engine"] = VisionEngine(speak=os.getenv("VISIONGUIDE_SPEECH", "1") == "1", navigator=NAV)
        return S["engine"]


def _worker(stop_evt):
    """PC camera loop (server side)."""
    from camera import Camera
    S["status"], S["error"] = "starting", None
    cam = None
    try:
        engine = _get_engine()
        cam = Camera(index=int(os.getenv("VISIONGUIDE_CAMERA", config.CAMERA_INDEX))).open()
        S["status"], S["source"] = "running", "server"
        while not S["stop"].is_set() and not stop_evt.is_set():
            frame = cam.read()
            if frame is not None:
                engine.process(frame)
    except Exception as e:
        S["status"], S["error"] = "error", str(e)
        print("[Backend] ERROR:", e)
    finally:
        if cam:
            cam.release()
        if S["status"] == "running":
            S["status"] = "stopped"
        if S["source"] == "server":
            S["source"] = "none"


def _server_camera_alive():
    t = S["worker"]
    return t is not None and t.is_alive()


def _start_server_camera():
    if _server_camera_alive():
        return
    S["worker_stop"] = threading.Event()
    S["worker"] = threading.Thread(target=_worker, args=(S["worker_stop"],), daemon=True)
    S["worker"].start()


def _stop_server_camera():
    if _server_camera_alive():
        S["worker_stop"].set()
        S["worker"].join(timeout=5)       # releases the webcam so the browser can use it
    if S["source"] == "server":
        S["source"], S["status"] = "none", "stopped"


@asynccontextmanager
async def lifespan(app):
    if os.getenv("VISIONGUIDE_AUTOSTART", "0") == "1":
        _start_server_camera()
    yield
    S["stop"].set()
    S["worker_stop"].set()


app = FastAPI(title="VisionGuide AI API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def _latest():
    e = S["engine"]
    if e is None:
        return {}
    with e.lock:
        return dict(e.latest)


def _state():
    """Everything the dashboard needs in ONE call."""
    d = _latest()
    sp = d.get("spatial", {})
    route = NAV.status() if NAV else {"state": "disabled", "destination": None, "current": None,
                                      "instruction": "", "route": []}
    return {"status": S["status"], "error": S["error"], "source": S["source"], "fps": d.get("fps", 0),
            "depth_enabled": d.get("depth_enabled", False), "frame": d.get("frame"),
            "decision": d.get("decision", "Waiting..."), "message": d.get("message", ""),
            "left": sp.get("left", "UNKNOWN"), "center": sp.get("center", "UNKNOWN"),
            "right": sp.get("right", "UNKNOWN"), "risk_level": sp.get("risk_level", "UNKNOWN"),
            "closeness": sp.get("closeness", {}), "obstacles": sp.get("obstacles", []),
            "detections": d.get("detections", []), "markers": d.get("markers", []), "route": route}


@app.get("/", response_class=HTMLResponse)
def dashboard():
    if os.path.exists(INDEX_FILE):
        return FileResponse(INDEX_FILE, media_type="text/html")
    return HTMLResponse("<h2>VisionGuide AI API is running</h2><p>index.html not found. "
                        "See <a href='/docs'>/docs</a>.</p>")


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/state")
def state():
    return _state()


@app.get("/status")
def status():
    d = _latest()
    return {"status": S["status"], "error": S["error"], "fps": d.get("fps", 0),
            "depth_enabled": d.get("depth_enabled", False),
            "note": "relative_depth is 0 (far) to 1 (near), not meters"}


@app.get("/detections")
def detections():
    return {"detections": _latest().get("detections", [])}


@app.get("/navigation")
def navigation():
    d = _latest()
    sp = d.get("spatial", {})
    return {"decision": d.get("decision", "Waiting..."), "message": d.get("message", ""), "left": sp.get("left", "UNKNOWN"),
            "center": sp.get("center", "UNKNOWN"), "right": sp.get("right", "UNKNOWN"),
            "risk_level": sp.get("risk_level", "UNKNOWN"), "obstacles": sp.get("obstacles", [])}


@app.get("/video")
def video():
    def gen():
        while not S["stop"].is_set():
            e = S["engine"]
            jpg = e.latest_jpeg if (e and S["source"] == "server") else None
            if jpg:
                yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.1)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")


# ---------- camera source control ----------
class ServerCameraIn(BaseModel):
    on: bool = True


@app.post("/server-camera")
def server_camera(body: ServerCameraIn):
    """Turn the PC (OpenCV) camera on/off. Turning it off frees the webcam for the browser."""
    if body.on:
        S["error"] = None
        _start_server_camera()
    else:
        _stop_server_camera()
    return {"ok": True, **_state()}


def _analyze(data):
    import cv2
    import numpy as np
    frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if frame is None or frame.size == 0:
        return {"ok": False, "error": "Bad image received", **_state()}
    with ANALYZE_LOCK:
        try:
            engine = _get_engine()
        except Exception as e:                 # e.g. YOLO weights could not be downloaded
            S["status"], S["error"] = "error", f"Could not start AI engine: {e}"
            return {"ok": False, **_state()}
        S["status"], S["error"], S["source"] = "running", None, "browser"
        try:
            engine.process(frame)
        except Exception as e:
            S["error"] = f"Frame failed: {e}"
            return {"ok": False, **_state()}
    return {"ok": True, **_state()}


@app.post("/analyze")
async def analyze(request: Request):
    """Browser camera: POST one JPEG frame (body = raw image bytes). Returns the full dashboard state."""
    if _server_camera_alive():
        await run_in_threadpool(_stop_server_camera)   # only one camera source at a time
    data = await request.body()
    return await run_in_threadpool(_analyze, data)


# ---------- indoor route ----------
class DestinationIn(BaseModel):
    destination: Optional[str] = None      # place name or marker id; null clears


@app.get("/map")
def get_map():
    if NAV is None:
        return {"nodes": []}
    return {"nodes": [{"id": i, "name": n} for i, n in NAV.graph.names.items()]}


@app.get("/route")
def get_route():
    if NAV is None:
        return {"state": "disabled", "destination": None, "current": None, "instruction": "", "route": []}
    return NAV.status()


@app.post("/destination")
def set_destination(body: DestinationIn):
    if NAV is None:
        return {"ok": False, "error": "navigation disabled (map.json problem)"}
    if body.destination in (None, ""):
        NAV.clear()
        return {"ok": True, **NAV.status()}
    if not NAV.set_destination(body.destination):
        return {"ok": False, "error": f"Unknown destination '{body.destination}'"}
    return {"ok": True, **NAV.status()}
