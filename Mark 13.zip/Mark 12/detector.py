"""detector.py - YOLOv8 object detection (Ultralytics)."""
import os
import cv2
import config


class DetectorError(Exception):
    pass


class Detector:
    def __init__(self, model_path=config.YOLO_MODEL, conf=config.YOLO_CONF,
                 imgsz=config.YOLO_IMGSZ):
        try:
            from ultralytics import YOLO
            if os.path.exists(model_path):
                weights = model_path                       # local file -> use it
            elif os.path.exists(os.path.basename(model_path)):
                weights = os.path.basename(model_path)     # file in project root
            else:                                          # download from HuggingFace
                from huggingface_hub import hf_hub_download
                folder = os.path.dirname(model_path) or "."
                os.makedirs(folder, exist_ok=True)
                weights = hf_hub_download(config.YOLO_HF_REPO, os.path.basename(model_path),
                                          local_dir=folder)
            self.model = YOLO(weights)
        except Exception as e:
            raise DetectorError(f"Could not load YOLO model '{model_path}': {e}")
        self.conf, self.imgsz = conf, imgsz

    def detect(self, frame):
        """Return a list of dicts: class, confidence, x1,y1,x2,y2, center_x, center_y."""
        if frame is None or frame.size == 0:
            return []
        h, w = frame.shape[:2]
        try:
            results = self.model.predict(frame, imgsz=self.imgsz, conf=self.conf,
                                         device="cpu", verbose=False)
        except Exception as e:
            print("[Detector] inference failed:", e)
            return []
        out = []
        r = results[0]
        if r.boxes is None:
            return out
        for box in r.boxes:
            x1, y1, x2, y2 = [int(v) for v in box.xyxy[0].tolist()]
            x1, x2 = max(0, min(x1, w - 1)), max(0, min(x2, w - 1))
            y1, y2 = max(0, min(y1, h - 1)), max(0, min(y2, h - 1))
            if x2 <= x1 or y2 <= y1:
                continue
            out.append({"class": r.names[int(box.cls[0])],
                        "confidence": round(float(box.conf[0]), 2),
                        "x1": x1, "y1": y1, "x2": x2, "y2": y2,
                        "center_x": (x1 + x2) // 2, "center_y": (y1 + y2) // 2})
        return out


def draw_detections(frame, detections):
    for d in detections:
        cv2.rectangle(frame, (d["x1"], d["y1"]), (d["x2"], d["y2"]), (0, 255, 0), 2)
        label = f'{d["class"]} {d["confidence"]:.2f}'
        if d.get("relative_depth") is not None:
            label += f' d={d["relative_depth"]:.2f}'
        cv2.putText(frame, label, (d["x1"], max(15, d["y1"] - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
    return frame
