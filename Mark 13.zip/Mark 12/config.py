"""config.py - All easy-to-change settings for VisionGuide AI."""
import os
# Camera
CAMERA_INDEX = 0          # 0 = built-in, 1 or 2 = external USB webcam
FRAME_WIDTH = 640
FRAME_HEIGHT = 480

# YOLO (CPU friendly)
YOLO_MODEL = "models/yolov8n.pt"   # use models/indoor_best.pt after custom training
YOLO_HF_REPO = "Ultralytics/YOLOv8"  # HuggingFace repo used if the local file is missing
YOLO_CONF = 0.30
YOLO_IMGSZ = 416                   # smaller = faster (try 256, 320, 416, 640)

# MiDaS (relative depth, CPU friendly)
DEPTH_BACKEND = "huggingface"      # "huggingface" (Intel MiDaS/DPT) or "torchhub" (original MiDaS_small)
DEPTH_HF_MODEL = "Intel/dpt-swinv2-tiny-256"   # small MiDaS 3.1 model, CPU friendly
# Other HF options: "Intel/dpt-hybrid-midas" (more accurate, ~490 MB, slower),
#                   "Intel/dpt-large" (most accurate, slowest)
DEPTH_MODEL = "MiDaS_small"        # used only when DEPTH_BACKEND = "torchhub" (or as fallback)
HF_CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "hf_cache")
DEPTH_EVERY = 3                    # run depth every N frames (frame skipping)

# Spatial analysis. relative_depth: 0 = far, 1 = near (NOT meters!)
BLOCKED_THRESHOLD = 0.50
HIGH_RISK_THRESHOLD = 0.75
MIN_ZONE_OVERLAP = 0.25            # fraction of box width that must be inside a zone

# Decision stabilization / voice
STABLE_FRAMES = 5                  # frames a decision must repeat before it is announced
SPEECH_RATE = 170

# Voice: describe obstacles
SPEECH_MAX_OBJECTS = 2            # announce at most this many obstacles
FRIENDLY_NAMES = {"tv": "television", "cell phone": "mobile phone", "potted plant": "plant",
                  "dining table": "table", "couch": "sofa"}
SPOKEN_TEXT = {"Move forward": "Move forward", "Turn left": "Turn left",
               "Turn right": "Turn right", "Stop": "Wait"}
SPEECH_REPEAT_SECONDS = 4

# Wall / large-obstacle detection from depth (no YOLO needed)
USE_DEPTH_WALLS = True
WALL_DEPTH_THRESHOLD = 0.70     # pixel counts as "near" if relative depth >= this
WALL_AREA_FRACTION = 0.55       # zone is a wall if this fraction of its pixels is near

# ---------------- Level 3: marker-based indoor navigation ----------------
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MAP_FILE = os.path.join(BASE_DIR, "map.json")
ARUCO_DICT = "DICT_4X4_50"
MARKER_MIN_SIZE = 60        # marker side in pixels before it counts as "reached" (~1-2 m for a 15 cm marker)
NAV_REPEAT_SECONDS = 12     # repeat the route instruction every N seconds while path is clear
ARRIVED_SECONDS = 8         # how long "You have reached ..." stays active
