"""main.py - Real-time VisionGuide AI (OpenCV window).  Press Q to quit.
Examples:  python main.py
           python main.py --dest "Library"          (marker-based route guidance)
           python main.py --camera 1 --no-speech --imgsz 256 --depth-every 5
Keys: Q quit | 1-9 choose destination from the map | C clear destination"""
import argparse
import cv2
import config
from camera import Camera, CameraError
from detector import DetectorError
from engine import VisionEngine
from route import RouteGraph, RouteNavigator


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--camera", type=int, default=config.CAMERA_INDEX)
    p.add_argument("--model", default=config.YOLO_MODEL)
    p.add_argument("--imgsz", type=int, default=config.YOLO_IMGSZ)
    p.add_argument("--depth-every", type=int, default=config.DEPTH_EVERY)
    p.add_argument("--no-depth", action="store_true")
    p.add_argument("--no-speech", action="store_true")
    p.add_argument("--no-nav", action="store_true", help="turn off marker navigation")
    p.add_argument("--map", default=config.MAP_FILE)
    p.add_argument("--dest", default=None, help='destination name or marker id, e.g. "Library"')
    a = p.parse_args()

    navigator, places = None, []
    if not a.no_nav:
        try:
            navigator = RouteNavigator(RouteGraph.load(a.map))
            places = list(navigator.graph.names.values())
            if a.dest and not navigator.set_destination(a.dest):
                print(f"Unknown destination '{a.dest}'. Available: {places}")
        except Exception as e:
            print("MAP ERROR (navigation disabled):", e)
            navigator = None

    try:
        engine = VisionEngine(a.model, a.imgsz, not a.no_depth, a.depth_every,
                              not a.no_speech, navigator)
    except DetectorError as e:
        print("MODEL ERROR:", e)
        return
    if places:
        print("Destinations:", ", ".join(f"{i + 1}={n}" for i, n in enumerate(places[:9])))
    try:
        with Camera(index=a.camera) as cam:
            print("Running. Press Q in the video window to quit.")
            while True:
                frame = cam.read()
                if frame is None:
                    continue
                _, annotated = engine.process(frame)
                if places:
                    cv2.putText(annotated, "Keys: " + " ".join(f"{i + 1}={n}" for i, n in enumerate(places[:9])),
                                (10, 168), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1, cv2.LINE_AA)
                cv2.imshow("VisionGuide AI", annotated)
                dv = engine.depth_view()
                if dv is not None:
                    cv2.imshow("Relative Depth (bright = near)", dv)
                k = cv2.waitKey(1) & 0xFF
                if k in (ord("q"), ord("Q")):
                    break
                if navigator and ord("1") <= k <= ord("9") and k - ord("1") < len(places):
                    navigator.set_destination(places[k - ord("1")])
                elif navigator and k in (ord("c"), ord("C")):
                    navigator.clear()
    except CameraError as e:
        print("CAMERA ERROR:", e)
    except KeyboardInterrupt:
        pass
    finally:
        engine.close()
        cv2.destroyAllWindows()
        print("Stopped.")


if __name__ == "__main__":
    main()
