"""engine.py - The Python vision engine: Camera frame -> YOLO -> MiDaS -> fusion ->
spatial analysis -> decision -> stabilization -> voice. Used by main.py and the FastAPI backend."""
import threading
import time
import cv2
import config
from detector import Detector, draw_detections
from depth import DepthEstimator, attach_depth, depth_to_color
from spatial import analyze_spatial_scene, CLEAR, BLOCKED
from navigation import (navigation_decision, build_voice_message, describe_obstacles,
                        DecisionStabilizer, FORWARD)
from markers import MarkerDetector, draw_markers
from speech import Speaker

STATUS_COLORS = {"CLEAR": (0, 200, 0), "BLOCKED": (0, 165, 255), "HIGH RISK": (0, 0, 255)}


class VisionEngine:
    def __init__(self, model_path=config.YOLO_MODEL, imgsz=config.YOLO_IMGSZ,
                 use_depth=True, depth_every=config.DEPTH_EVERY, speak=True, navigator=None):
        self.detector = Detector(model_path, imgsz=imgsz)
        self.navigator, self.marker_detector = navigator, None
        if navigator is not None:                      # Level 3: marker navigation
            try:
                self.marker_detector = MarkerDetector()
            except Exception as ex:
                print("[Engine] WARNING marker navigation disabled:", ex)
        self.depth = None
        if use_depth:
            try:
                self.depth = DepthEstimator()
            except Exception as e:           # app still works with YOLO only
                print("[Engine] WARNING depth disabled:", e)
        self.depth_every = max(1, depth_every)
        self.stabilizer = DecisionStabilizer(config.STABLE_FRAMES)
        self.msg_stabilizer = DecisionStabilizer(config.STABLE_FRAMES)
        self.speaker = Speaker() if speak else None
        self.frame_count, self.depth_map, self.fps = 0, None, 0.0
        self.lock = threading.Lock()
        self.latest = {}
        self.latest_jpeg = None

    def process(self, frame):
        """Return (result_dict, annotated_frame)."""
        t0 = time.time()
        h, w = frame.shape[:2]
        detections = self.detector.detect(frame)
        if self.depth is not None and self.frame_count % self.depth_every == 0:
            try:
                self.depth_map = self.depth.estimate(frame)
            except Exception as e:
                print("[Engine] depth failed for this frame:", e)
        self.frame_count += 1
        markers = self.marker_detector.detect(frame) if self.marker_detector else []
        if self.navigator:
            self.navigator.update(markers)
        detections = attach_depth(detections, self.depth_map)
        spatial = analyze_spatial_scene(detections, w, h, depth_map=self.depth_map)
        raw = navigation_decision(spatial)
        stable, changed = self.stabilizer.update(raw)
        # Safety first: obstacle warnings. When the path is clear, give the route instruction.
        msg_raw = build_voice_message(raw, spatial)
        nav_text = self.navigator.current_text() if self.navigator else None
        if nav_text and raw == FORWARD and not describe_obstacles(spatial):
            msg_raw = nav_text
        message, _ = self.msg_stabilizer.update(msg_raw)
        if message and self.speaker:
            self.speaker.say(message, config.NAV_REPEAT_SECONDS if message == nav_text else None)
        inst = 1.0 / max(1e-3, time.time() - t0)
        self.fps = inst if self.fps == 0 else 0.9 * self.fps + 0.1 * inst
        result = {"detections": detections, "spatial": spatial, "raw_decision": raw,
                  "decision": stable or "Starting...", "message": message or "", "fps": round(self.fps, 1),
                  "depth_enabled": self.depth is not None, "frame": [w, h],
                  "markers": [{"id": m["id"], "size": m["size"],
                               "name": self.navigator.name(m["id"]) if self.navigator else None}
                              for m in markers],
                  "route": self.navigator.status() if self.navigator else None}
        annotated = draw_overlay(frame.copy(), result, markers)
        ok, jpg = cv2.imencode(".jpg", annotated)
        with self.lock:
            self.latest = result
            if ok:
                self.latest_jpeg = jpg.tobytes()
        return result, annotated

    def depth_view(self):
        return None if self.depth_map is None else depth_to_color(self.depth_map)

    def close(self):
        if self.speaker:
            self.speaker.close()


def draw_overlay(frame, result, markers=()):
    h, w = frame.shape[:2]
    frame = draw_detections(frame, result["detections"])
    names = {m["id"]: m["name"] for m in result.get("markers", []) if m.get("name")}
    frame = draw_markers(frame, markers, names)
    for x in (w // 3, 2 * w // 3):
        cv2.line(frame, (x, 0), (x, h), (255, 255, 255), 1)
    sp = result["spatial"]
    for i, z in enumerate(("left", "center", "right")):
        s = sp[z]
        cv2.putText(frame, f"{z.upper()}: {s}", (10, 25 + i * 24), cv2.FONT_HERSHEY_SIMPLEX,
                    0.65, STATUS_COLORS[s], 2, cv2.LINE_AA)
    cl = sp.get("closeness", {})
    cv2.putText(frame, f"Depth:{'ON' if result.get('depth_enabled') else 'OFF'}  objs:{len(result['detections'])}  "
                       f"closeness L/C/R: {cl.get('left', 0)} {cl.get('center', 0)} {cl.get('right', 0)}",
                (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1, cv2.LINE_AA)
    r = result.get("route")
    if r:
        line = f"Route: {r['state']} | You: {r['current'] or '?'} -> {r['destination'] or '-'}"
        cv2.putText(frame, line, (10, 124), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 255), 1, cv2.LINE_AA)
        cv2.putText(frame, r["instruction"][:75], (10, 146), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (255, 0, 255), 1, cv2.LINE_AA)
    cv2.rectangle(frame, (0, h - 62), (w, h), (0, 0, 0), -1)
    cv2.putText(frame, "Voice: " + result.get("message", ""), (10, h - 42),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 1, cv2.LINE_AA)
    cv2.putText(frame, f"Decision: {result['decision'].upper()}   FPS: {result['fps']}"
                       f"   Risk: {sp['risk_level']}", (10, h - 14),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
    return frame
