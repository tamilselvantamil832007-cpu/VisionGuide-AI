"""depth.py - MiDaS RELATIVE depth + YOLO/MiDaS fusion.

relative_depth here means CLOSENESS in [0, 1]: 0 = far, 1 = near.
It is NOT meters.

FIX: the depth range (lo/hi) is now smoothed over time instead of being min-max
normalised separately for every frame. This stops a flat wall from being stretched into
noise (wall missed -> "Move forward") and stops a far object from looking "near" just
because it is the nearest thing in an otherwise empty frame.
"""
import os
import cv2
import numpy as np
import config


class DepthError(Exception):
    pass


class DepthEstimator:
    """MiDaS relative depth. Backend 'huggingface' (transformers, Intel MiDaS/DPT models)
    with automatic fallback to the original torch.hub MiDaS_small."""

    RANGE_ALPHA = 0.05      # how fast the lo/hi range adapts (0.05 = slow, 0.3 = fast)

    def __init__(self, model_type=config.DEPTH_MODEL, backend=config.DEPTH_BACKEND):
        try:
            import torch
        except Exception as e:
            raise DepthError(f"PyTorch not available: {e}")
        self.torch = torch
        torch.set_num_threads(max(1, (torch.get_num_threads() or 4)))
        self.backend = None
        self._lo = self._hi = None          # running depth range (temporal smoothing)
        errors = []
        if backend == "huggingface":
            try:
                self._load_hf()
                self.backend = "huggingface"
            except Exception as e:
                errors.append(f"HuggingFace ({config.DEPTH_HF_MODEL}): {e}")
                print("[Depth] HuggingFace load failed, trying torch.hub MiDaS_small:", e)
        if self.backend is None:
            try:
                self._load_hub(model_type)
                self.backend = "torchhub"
            except Exception as e:
                errors.append(f"torch.hub ({model_type}): {e}")
        if self.backend is None:
            raise DepthError("Could not load a depth model. " + " | ".join(errors) +
                             ". First run needs internet; try 'pip install transformers timm'.")
        print(f"[Depth] using backend: {self.backend}")

    # ---- loaders ----
    def _load_hf(self):
        from transformers import AutoImageProcessor, AutoModelForDepthEstimation
        os.makedirs(config.HF_CACHE_DIR, exist_ok=True)
        name = config.DEPTH_HF_MODEL
        self.processor = AutoImageProcessor.from_pretrained(name, cache_dir=config.HF_CACHE_DIR)
        self.model = AutoModelForDepthEstimation.from_pretrained(name, cache_dir=config.HF_CACHE_DIR)
        self.model.to("cpu").eval()

    def _load_hub(self, model_type):
        torch = self.torch
        self.model = torch.hub.load("intel-isl/MiDaS", model_type, trust_repo=True)
        self.model.to("cpu").eval()
        transforms = torch.hub.load("intel-isl/MiDaS", "transforms", trust_repo=True)
        self.transform = (transforms.small_transform if model_type == "MiDaS_small"
                          else transforms.dpt_transform)

    # ---- inference ----
    def estimate(self, frame):
        """Return float32 map (same size as frame), 0 = far, 1 = near."""
        if frame is None or frame.size == 0:
            raise DepthError("Invalid frame")
        torch = self.torch
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        with torch.no_grad():
            if self.backend == "huggingface":
                inputs = self.processor(images=rgb, return_tensors="pt")
                pred = self.model(**inputs).predicted_depth          # (1, H, W), higher = nearer
            else:
                pred = self.model(self.transform(rgb).to("cpu"))     # (1, H, W)
            pred = torch.nn.functional.interpolate(
                pred.unsqueeze(1), size=frame.shape[:2],
                mode="bicubic", align_corners=False).squeeze()
        raw = pred.cpu().numpy().astype(np.float32)
        return self._normalize_smooth(raw)

    def _normalize_smooth(self, raw):
        """Normalise with a slowly adapting range instead of this frame's own min/max."""
        lo, hi = float(np.percentile(raw, 2)), float(np.percentile(raw, 98))
        if self._lo is None:
            self._lo, self._hi = lo, hi
        else:
            a = self.RANGE_ALPHA
            self._lo += a * (lo - self._lo)
            self._hi += a * (hi - self._hi)
        return np.clip((raw - self._lo) / (self._hi - self._lo + 1e-6), 0, 1).astype(np.float32)

    def reset_range(self):
        """Call this if the scene changes completely (e.g. camera switched)."""
        self._lo = self._hi = None


def normalize_depth(d):
    """Plain per-frame min-max (kept for tests / offline use)."""
    d = d.astype(np.float32)
    lo, hi = float(d.min()), float(d.max())
    return (d - lo) / (hi - lo + 1e-6)


def depth_to_color(depth_map):
    return cv2.applyColorMap((depth_map * 255).astype(np.uint8), cv2.COLORMAP_MAGMA)


def attach_depth(detections, depth_map):
    """FUSION: add 'relative_depth' (median of the middle part of each box)."""
    for d in detections:
        d["relative_depth"] = None
        if depth_map is None:
            continue
        h, w = depth_map.shape[:2]
        bw, bh = d["x2"] - d["x1"], d["y2"] - d["y1"]
        x1 = int(np.clip(d["x1"] + bw * 0.25, 0, w - 1)); x2 = int(np.clip(d["x2"] - bw * 0.25, 0, w))
        y1 = int(np.clip(d["y1"] + bh * 0.25, 0, h - 1)); y2 = int(np.clip(d["y2"] - bh * 0.25, 0, h))
        region = depth_map[y1:max(y2, y1 + 1), x1:max(x2, x1 + 1)]
        if region.size:
            d["relative_depth"] = round(float(np.median(region)), 2)
    return detections
