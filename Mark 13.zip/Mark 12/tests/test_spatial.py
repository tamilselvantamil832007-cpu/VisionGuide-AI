from spatial import analyze_spatial_scene

def det(x1, x2, depth, cls="person"):
    return {"class": cls, "confidence": 0.9, "x1": x1, "y1": 100, "x2": x2, "y2": 400,
            "center_x": (x1 + x2) // 2, "center_y": 250, "relative_depth": depth}

def test_empty_scene_is_clear():
    r = analyze_spatial_scene([], 640, 480)
    assert r["left"] == r["center"] == r["right"] == "CLEAR" and r["risk_level"] == "LOW"

def test_near_object_in_center_blocks_center_only():
    r = analyze_spatial_scene([det(250, 390, 0.6)], 640, 480)
    assert r["center"] == "BLOCKED" and r["left"] == "CLEAR" and r["right"] == "CLEAR"

def test_very_near_center_is_high_risk():
    r = analyze_spatial_scene([det(250, 390, 0.9)], 640, 480)
    assert r["center"] == "HIGH RISK" and r["risk_level"] == "HIGH"

def test_far_object_is_clear():
    assert analyze_spatial_scene([det(250, 390, 0.2)], 640, 480)["center"] == "CLEAR"

def test_missing_depth_uses_box_size_fallback():
    d = det(0, 640, None); d["y1"], d["y2"] = 0, 480
    assert analyze_spatial_scene([d], 640, 480)["center"] != "CLEAR"

def test_depth_wall_blocks_center():
    import numpy as np
    dm = np.full((480, 640), 0.2, dtype=np.float32); dm[:, 200:440] = 0.85
    r = analyze_spatial_scene([], 640, 480, depth_map=dm)
    assert r["center"] != "CLEAR" and r["left"] == "CLEAR"

def test_far_depth_scene_is_clear():
    import numpy as np
    r = analyze_spatial_scene([], 640, 480, depth_map=np.full((480, 640), 0.2, dtype=np.float32))
    assert r["center"] == "CLEAR"
