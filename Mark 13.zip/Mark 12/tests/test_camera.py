import pytest
from camera import Camera, CameraError

def test_camera_reads_frame_or_skips():
    try:
        cam = Camera(index=0).open()
    except CameraError:
        pytest.skip("No camera available")
    frame = cam.read()
    cam.release()
    assert frame is None or frame.ndim == 3

def test_read_before_open_raises():
    with pytest.raises(CameraError):
        Camera().read()
