from navigation import DecisionStabilizer

def test_needs_n_repeats():
    s = DecisionStabilizer(3)
    assert s.update("Stop") == (None, False)
    assert s.update("Stop") == (None, False)
    assert s.update("Stop") == ("Stop", True)
    assert s.update("Stop") == ("Stop", False)      # no repeat announcement

def test_flickering_is_ignored():
    s = DecisionStabilizer(3)
    for d in ["Move forward"] * 3: s.update(d)
    for d in ["Turn left", "Move forward", "Turn right", "Move forward"]:
        assert s.update(d) == ("Move forward", False)

def test_changes_after_stable():
    s = DecisionStabilizer(2)
    s.update("Move forward"); s.update("Move forward")
    s.update("Turn left")
    assert s.update("Turn left") == ("Turn left", True)
