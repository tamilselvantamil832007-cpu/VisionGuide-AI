import numpy as np
import pytest
from depth import DepthEstimator, DepthError, attach_depth, normalize_depth

def test_normalize_range():
    d = normalize_depth(np.array([[1.0, 5.0], [9.0, 3.0]]))
    assert d.min() >= 0 and d.max() <= 1

def test_attach_depth_fusion():
    dm = np.zeros((100, 100), dtype=np.float32); dm[:, 50:] = 0.8
    det = [{"class": "x", "x1": 60, "y1": 10, "x2": 95, "y2": 90, "center_x": 77, "center_y": 50}]
    assert attach_depth(det, dm)[0]["relative_depth"] == 0.8
    assert attach_depth(det, None)[0]["relative_depth"] is None

def test_midas_inference():
    try:
        est = DepthEstimator()
    except DepthError as e:
        pytest.skip(f"MiDaS not available (needs internet first time): {e}")
    out = est.estimate(np.random.randint(0, 255, (240, 320, 3), dtype=np.uint8))
    assert out.shape == (240, 320) and 0 <= out.min() and out.max() <= 1
