from navigation import navigation_decision

def sp(l, c, r): return {"left": l, "center": c, "right": r}

def test_forward():  assert navigation_decision(sp("BLOCKED", "CLEAR", "BLOCKED")) == "Move forward"
def test_left():     assert navigation_decision(sp("CLEAR", "BLOCKED", "CLEAR")) == "Turn left"
def test_right():    assert navigation_decision(sp("BLOCKED", "BLOCKED", "CLEAR")) == "Turn right"
def test_stop():     assert navigation_decision(sp("HIGH RISK", "BLOCKED", "BLOCKED")) == "Stop"
def test_all_blocked_stops(): assert navigation_decision(sp("HIGH RISK", "HIGH RISK", "BLOCKED")) == "Stop"

def test_voice_message_names_obstacle():
    from navigation import build_voice_message
    s = {"left": "CLEAR", "center": "BLOCKED", "right": "CLEAR",
         "obstacles": [{"class": "laptop", "zones": ["center"], "closeness": 0.6}]}
    assert build_voice_message("Turn left", s) == "Laptop ahead. Turn left"

def test_stop_is_spoken_as_wait():
    from navigation import build_voice_message
    s = {"obstacles": []}
    assert build_voice_message("Stop", s) == "Wait"
