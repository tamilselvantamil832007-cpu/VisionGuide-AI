from speech import Speaker

def test_speaker_does_not_crash_and_skips_repeats():
    s = Speaker()
    s.say("Stop")
    assert s.say("Stop") is False       # same text is not repeated
    s.close()
