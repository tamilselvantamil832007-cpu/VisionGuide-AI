import os
os.environ["VISIONGUIDE_AUTOSTART"] = "0"       # do not open camera during tests
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").json() == {"ok": True}

def test_status_navigation_detections():
    assert "status" in client.get("/status").json()
    assert "decision" in client.get("/navigation").json()
    assert client.get("/detections").json() == {"detections": []}

def test_map_route_destination():
    assert len(client.get("/map").json()["nodes"]) >= 2
    r = client.post("/destination", json={"destination": "Library"}).json()
    assert r["ok"] and r["destination"] == "Library"
    assert client.get("/route").json()["state"] == "searching"
    assert client.post("/destination", json={"destination": "Moon"}).json()["ok"] is False
    assert client.post("/destination", json={"destination": None}).json()["state"] == "idle"


def test_state_and_dashboard():
    st = client.get("/state").json()
    for k in ("status", "decision", "left", "center", "right", "detections", "route", "source"):
        assert k in st
    assert client.get("/").status_code == 200

def test_server_camera_off():
    assert client.post("/server-camera", json={"on": False}).json()["ok"] is True
