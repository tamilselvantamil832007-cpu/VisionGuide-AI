import time
import pytest
import config
from route import RouteGraph, RouteNavigator


def make():
    g = RouteGraph.load()
    return g, RouteNavigator(g, min_size=60)

def mk(i, size=100): return [{"id": i, "size": size}]


def test_shortest_path():
    g, _ = make()
    assert g.shortest_path(0, 4) == [0, 1, 3, 4]
    assert g.shortest_path(4, 2) == [4, 3, 1, 2]
    assert g.shortest_path(2, 2) == [2]

def test_find_by_name_and_id():
    g, _ = make()
    assert g.find("library") == 2 and g.find("3") == 3 and g.find("Moon") is None

def test_bad_edge_raises():
    with pytest.raises(ValueError):
        RouteGraph([{"id": 0, "name": "A"}], [{"from": 0, "to": 9, "instruction": "x"}])

def test_guidance_flow():
    _, n = make()
    assert n.set_destination("Library") and n.state == "searching"
    n.update(mk(0))
    assert n.state == "guiding" and n.current_text() == "Entrance. Walk straight about 10 steps"
    n.update(mk(1))
    assert n.current_text() == "Reception. Turn left and walk about 15 steps"
    n.update(mk(2))
    assert n.state == "arrived" and n.current_text() == "You have reached Library"

def test_far_marker_is_ignored():
    _, n = make()
    n.set_destination("Library")
    n.update(mk(0, size=20))
    assert n.state == "searching" and n.current is None

def test_destination_set_while_standing_at_marker():
    _, n = make()
    n.update(mk(1))
    n.set_destination("Canteen")
    assert n.state == "guiding" and "right" in n.current_text()

def test_arrival_expires(monkeypatch):
    _, n = make()
    n.update(mk(2)); n.set_destination("Library")
    assert n.state == "arrived"
    monkeypatch.setattr(config, "ARRIVED_SECONDS", -1)
    assert n.current_text() is None and n.state == "idle"

def test_unknown_destination():
    _, n = make()
    assert n.set_destination("Moon") is False
