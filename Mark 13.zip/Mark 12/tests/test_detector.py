import numpy as np
import pytest
from detector import Detector, DetectorError

def test_detector_runs_on_blank_frame():
    try:
        det = Detector()
    except DetectorError as e:
        pytest.skip(f"YOLO model not available: {e}")
    assert det.detect(np.zeros((480, 640, 3), dtype=np.uint8)) == []
    assert det.detect(None) == []
