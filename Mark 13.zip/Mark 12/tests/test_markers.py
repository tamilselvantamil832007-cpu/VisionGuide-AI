import cv2
import numpy as np
import pytest
from markers import MarkerDetector, MarkerError, generate_marker_image

def test_generate_and_detect_marker():
    try:
        det = MarkerDetector()
    except MarkerError as e:
        pytest.skip(str(e))
    frame = np.full((480, 640, 3), 255, np.uint8)
    m = cv2.cvtColor(cv2.resize(generate_marker_image(3, 200), (150, 150), interpolation=cv2.INTER_NEAREST),
                     cv2.COLOR_GRAY2BGR)
    frame[100:250, 200:350] = m
    found = det.detect(frame)
    assert [f["id"] for f in found] == [3] and found[0]["size"] > 100

def test_no_marker_in_blank_frame():
    try:
        det = MarkerDetector()
    except MarkerError as e:
        pytest.skip(str(e))
    assert det.detect(np.zeros((480, 640, 3), np.uint8)) == []
