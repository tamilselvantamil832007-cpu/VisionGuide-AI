"""speech.py - Voice guidance. pyttsx3 first, Windows PowerShell speech as fallback."""
import queue
import subprocess
import threading
import time
import config


def _speak_pyttsx3(text, rate):
    import pyttsx3
    engine = pyttsx3.init()      # fresh engine each time = more reliable on Windows
    engine.setProperty("rate", rate)
    engine.say(text)
    engine.runAndWait()
    engine.stop()


def _speak_powershell(text, rate):
    text = text.replace("'", "")
    cmd = ("Add-Type -AssemblyName System.Speech; "
           f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{text}')")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                   creationflags=flags, timeout=15, check=True)


class Speaker:
    def __init__(self, rate=config.SPEECH_RATE):
        self.rate = rate
        self.available = True
        self.last = None
        self.last_time = 0.0
        self.q = queue.Queue(maxsize=1)
        self.methods = [("pyttsx3", _speak_pyttsx3), ("powershell", _speak_powershell)]
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def _worker(self):
        while True:
            text = self.q.get()
            if text is None:
                break
            spoken = False
            for name, fn in list(self.methods):
                try:
                    fn(text, self.rate)
                    spoken = True
                    break
                except Exception as e:
                    print(f"[Speech] {name} failed: {e}")
                    if len(self.methods) > 1:
                        self.methods.remove((name, fn))   # do not retry a broken method
            if not spoken:
                print("[Speech] No working voice method. Continuing without voice.")
                self.available = False
                break

    def say(self, text, repeat=None):
        """New sentence = speak now. Same sentence = repeat every `repeat` seconds
        (default SPEECH_REPEAT_SECONDS; 0 = never repeat)."""
        if not self.available or not text:
            return False
        text = config.SPOKEN_TEXT.get(text, text)
        now = time.time()
        repeat = config.SPEECH_REPEAT_SECONDS if repeat is None else repeat
        if text == self.last and (repeat <= 0 or now - self.last_time < repeat):
            return False
        self.last, self.last_time = text, now
        try:
            self.q.get_nowait()          # drop old waiting text
        except queue.Empty:
            pass
        self.q.put_nowait(text)
        return True

    def close(self):
        try:
            self.q.put_nowait(None)
        except queue.Full:
            pass
