"""speech_test.py - Check that voice works (4 commands + an obstacle sentence)."""
import time
from speech import Speaker

s = Speaker()
for t in ["Move forward", "Turn left", "Turn right", "Stop", "Laptop ahead. Turn left"]:
    print("Saying:", t)
    s.say(t)
    time.sleep(3.5)
s.close()
print("Finished")
