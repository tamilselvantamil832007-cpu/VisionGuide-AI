"""route.py - Map graph, shortest route and the RouteNavigator (marker-based guidance)."""
import heapq
import json
import time
import config


class RouteGraph:
    def __init__(self, nodes, edges):
        self.names = {int(n["id"]): n["name"] for n in nodes}
        self.adj = {i: {} for i in self.names}          # a -> {b: (steps, instruction)}
        for e in edges:
            a, b = int(e["from"]), int(e["to"])
            if a not in self.names or b not in self.names:
                raise ValueError(f"Edge {a}->{b} uses a marker id that is not in 'nodes'")
            steps = e.get("steps", 1)
            self.adj[a][b] = (steps, e["instruction"])
            if e.get("reverse_instruction"):
                self.adj[b][a] = (steps, e["reverse_instruction"])

    @classmethod
    def load(cls, path=config.MAP_FILE):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return cls(data["nodes"], data["edges"])

    def find(self, key):
        """Marker id (int or '2') or place name (any case) -> id, or None."""
        if isinstance(key, int) or (isinstance(key, str) and key.strip().isdigit()):
            k = int(key)
            return k if k in self.names else None
        for i, n in self.names.items():
            if str(key).strip().lower() == n.lower():
                return i
        return None

    def shortest_path(self, a, b):
        if a == b:
            return [a]
        dist, prev, pq = {a: 0}, {}, [(0, a)]
        while pq:
            d, u = heapq.heappop(pq)
            if u == b:
                break
            if d > dist.get(u, float("inf")):
                continue
            for v, (w, _) in self.adj[u].items():
                if d + w < dist.get(v, float("inf")):
                    dist[v], prev[v] = d + w, u
                    heapq.heappush(pq, (d + w, v))
        if b not in dist:
            return None
        path = [b]
        while path[-1] != a:
            path.append(prev[path[-1]])
        return path[::-1]

    def instruction(self, a, b):
        return self.adj[a][b][1]


class RouteNavigator:
    """States: idle | searching | guiding | arrived | no_route"""

    def __init__(self, graph, min_size=config.MARKER_MIN_SIZE):
        self.graph, self.min_size = graph, min_size
        self.destination = None
        self.current = None
        self.route = []
        self.state = "idle"
        self.text = None
        self.arrived_at = 0.0

    def name(self, i):
        return self.graph.names.get(i)

    def set_destination(self, key):
        dest = self.graph.find(key)
        if dest is None:
            return False
        self.destination, self.route = dest, []
        if self.current is None:
            self.state, self.text = "searching", "Scan a marker to find your location"
        else:
            self._plan()
        return True

    def clear(self):
        self.destination, self.route, self.state, self.text = None, [], "idle", None

    def _plan(self):
        cur, dest = self.current, self.destination
        if cur == dest:
            self.state, self.route = "arrived", [dest]
            self.text, self.arrived_at = f"You have reached {self.name(dest)}", time.time()
            return
        path = self.graph.shortest_path(cur, dest)
        if path is None:
            self.state, self.route = "no_route", []
            self.text = f"No route from {self.name(cur)} to {self.name(dest)}"
        else:
            self.state, self.route = "guiding", path
            self.text = f"{self.name(cur)}. {self.graph.instruction(cur, path[1])}"

    def update(self, markers):
        """markers: list of dicts with 'id' and 'size' (pixels), biggest first."""
        for m in markers:
            if m["id"] in self.graph.names and m["size"] >= self.min_size:
                if m["id"] != self.current:
                    self.current = m["id"]
                    if self.destination is not None and self.state != "arrived":
                        self._plan()
                break

    def current_text(self):
        if self.state == "arrived" and time.time() - self.arrived_at > config.ARRIVED_SECONDS:
            self.clear()
        return self.text

    def status(self):
        self.current_text()
        return {"state": self.state, "destination": self.name(self.destination),
                "current": self.name(self.current), "instruction": self.text or "",
                "route": [self.name(i) for i in self.route]}
