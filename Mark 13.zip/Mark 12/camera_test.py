"""camera_test.py - Check webcam and Iriun camera.
Usage:
    python camera_test.py
    python camera_test.py --index 1
    python camera_test.py --scan
"""

import argparse
import cv2
import config


def test_camera(index):
    print(f"Testing camera index {index}...")

    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)

    if not cap.isOpened():
        print(f"Camera {index}: NOT OPENED")
        cap.release()
        return False

    print(f"Camera {index}: OPENED")

    while True:
        ret, frame = cap.read()

        if not ret:
            print("Cannot read frame from camera.")
            break

        cv2.imshow("Camera Test", frame)

        key = cv2.waitKey(1) & 0xFF

        if key in (ord("q"), ord("Q")):
            break

    cap.release()
    cv2.destroyAllWindows()

    return True


def scan_cameras():
    working = []

    print("Scanning cameras...")

    for index in range(5):
        cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)

        if cap.isOpened():
            ret, frame = cap.read()

            if ret and frame is not None:
                print(f"Camera {index}: WORKING")
                working.append(index)
            else:
                print(f"Camera {index}: opened but no frame")
        else:
            print(f"Camera {index}: not available")

        cap.release()

    cv2.destroyAllWindows()

    return working


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--index",
        type=int,
        default=config.CAMERA_INDEX
    )

    parser.add_argument(
        "--scan",
        action="store_true",
        help="Find working camera indexes"
    )

    args = parser.parse_args()

    if args.scan:
        cameras = scan_cameras()
        print()
        print("Working camera indexes:", cameras)
        return

    test_camera(args.index)


if __name__ == "__main__":
    main()