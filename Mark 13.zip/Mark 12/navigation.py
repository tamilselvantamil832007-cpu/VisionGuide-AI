"""navigation.py - Navigation decision + DecisionStabilizer.
This is an ASSISTIVE aid only. It does NOT guarantee collision avoidance."""
from collections import deque
import config
from spatial import CLEAR

FORWARD, LEFT, RIGHT, STOP = "Move forward", "Turn left", "Turn right", "Stop"


def navigation_decision(spatial):
    """center clear -> forward, else left clear -> left, else right clear -> right, else stop."""
    if spatial["center"] == CLEAR:
        return FORWARD
    if spatial["left"] == CLEAR:
        return LEFT
    if spatial["right"] == CLEAR:
        return RIGHT
    return STOP


class DecisionStabilizer:
    """Accept a new decision only after it repeats `stable_frames` times in a row."""

    def __init__(self, stable_frames=5):
        self.stable_frames = max(1, stable_frames)
        self.history = deque(maxlen=self.stable_frames)
        self.current = None

    def update(self, decision):
        """Return (stable_decision, changed)."""
        self.history.append(decision)
        if (len(self.history) == self.stable_frames and len(set(self.history)) == 1
                and decision != self.current):
            self.current = decision
            return self.current, True
        return self.current, False


ZONE_WORDS = {"center": "ahead", "left": "on your left", "right": "on your right"}


def describe_obstacles(spatial, max_objects=config.SPEECH_MAX_OBJECTS):
    """Return phrases like ['laptop ahead', 'chair on your left'] (closest first)."""
    parts, seen = [], set()
    for ob in sorted(spatial["obstacles"], key=lambda o: -o["closeness"]):
        zone = "center" if "center" in ob["zones"] else ob["zones"][0]
        name = config.FRIENDLY_NAMES.get(ob["class"], ob["class"])
        if (name, zone) in seen:
            continue
        seen.add((name, zone))
        close = "very close " if ob["closeness"] >= config.HIGH_RISK_THRESHOLD else ""
        parts.append(f"{name} {close}{ZONE_WORDS[zone]}")
        if len(parts) >= max_objects:
            break
    return parts


def build_voice_message(decision, spatial):
    """Example: 'Laptop ahead. Turn left.'"""
    action = config.SPOKEN_TEXT.get(decision, decision)
    parts = describe_obstacles(spatial)
    if not parts:
        return action
    return (" and ".join(parts)).capitalize() + ". " + action
