"""generate_markers.py - Make printable marker images for every node in map.json.
Run:  python generate_markers.py      -> outputs/markers/*.png
Print each at about 15 cm x 15 cm (keep the white border!)."""
import os
import re
import cv2
import numpy as np
import config
from markers import generate_marker_image
from route import RouteGraph

OUT = os.path.join(config.BASE_DIR, "outputs", "markers")


def main():
    os.makedirs(OUT, exist_ok=True)
    graph = RouteGraph.load()
    for mid, name in graph.names.items():
        m = generate_marker_image(mid, 400)
        sheet = np.full((560, 520), 255, np.uint8)
        sheet[60:460, 60:460] = m
        cv2.putText(sheet, f"ID {mid}: {name}", (60, 520), cv2.FONT_HERSHEY_SIMPLEX, 0.9, 0, 2, cv2.LINE_AA)
        path = os.path.join(OUT, f"marker_{mid}_{re.sub(r'[^A-Za-z0-9]+', '_', name)}.png")
        cv2.imwrite(path, sheet)
        print("Saved", path)


if __name__ == "__main__":
    main()
